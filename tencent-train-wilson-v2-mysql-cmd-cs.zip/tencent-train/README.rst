

v1.0        2014-07-29

 * CS socket 编程 ，简单命令式交互，仅实现echo功能。exit或CTRL+D关闭会话。

 * 目标：重拾C/C++编程能力


v2.0        2014-08-01

 * 命令式商店实现，增加数据库功能(product和deal两表)，增加4个命令list, buy, add, del。

 * 目标：数据库编程，之前看了mysql++，最后没有用到，至此都是使用 linux C。
