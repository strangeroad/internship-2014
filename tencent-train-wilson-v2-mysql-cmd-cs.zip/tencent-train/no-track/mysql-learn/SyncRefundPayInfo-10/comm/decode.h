#ifndef _DECODE_H_
#define _DECODE_H_

#include "base64.h"
#include "qpay_encrypt_client.h"
#include <string>

int GenerateDigest(char* src, char* dest, int dsize);
int CheckDigest(char* src, ST_PUB_ANS* stAns);

/**
 * ���뺯��
 */
void encode(const char* szSpID, const char* szFrom, char* szTo, ST_PUB_ANS& stAns);

/**
 * ���뺯��
 */
void decode(const char* szSpID, const char* szFrom, char* szTo, ST_PUB_ANS& stAns);

/**
 * ���޼����˺�ʹ��
 */
void decode2(const char* szSpID, const char* szFrom, char* szTo, ST_PUB_ANS& stAns);

#endif
