#define TIXML_USE_STL
#include "globalconfig.h"
#include "error.h"
#include "tinyxml.h"

/**
 * ȡ�ӽڵ�
 */
TiXmlNode*  NODE_CHILD(TiXmlNode* pNode, const char* child=NULL)
{
    if(!pNode)
    {
        throw CException(ERR_NULL_XML_NODE, string("Get node failed:") + string(child), __FILE__, __LINE__);
    }

    TiXmlNode* pChild = child ?  pNode->FirstChild(child) : pNode->FirstChild();
    if (!pChild)
    {
        throw CException(ERR_NULL_XML_NODE, string("Get child node failed:") + string(child), __FILE__, __LINE__);
    }

    return pChild;
}

/**
 * ȡ���ڽڵ�
 */
TiXmlNode* NODE_NEXT(TiXmlNode* pNode)
{
    return pNode->NextSibling();
}

/**
 * ȡ�������
 */
string NODE_NAME(TiXmlNode* pNode)
{
    return pNode->Value() ? pNode->Value() : "";
}

/**
 * ȡ���ֵ
 */
string NODE_STR_VALUE(TiXmlNode* pNode)
{
    return pNode->ToElement()->GetText() ? pNode->ToElement()->GetText() : "";
}

/**
 * ȡ���ֵ
 */
int NODE_INT_VALUE(TiXmlNode* pNode)
{
    return pNode->ToElement()->GetText() ? atoi(pNode->ToElement()->GetText()) : 0;
}

/**
 * ȡ���ֵ
 */
LONG NODE_LONG_VALUE(TiXmlNode* pNode)
{
    return pNode->ToElement()->GetText() ? atoll(pNode->ToElement()->GetText()) : 0;
}

/**
 * ȡ�������
 */
string NODE_ATTR(TiXmlNode* pNode, const char* attribute)
{
    return pNode->ToElement()->Attribute(attribute) ? pNode->ToElement()->Attribute(attribute) : "";
}

/**
 * ��ȡ�����ļ�
 * @input       strCfgFile      �����ļ�
 */
GlobalConfig::GlobalConfig(const string& strCfgFile) throw(CException)
{    
    // ���������ļ�
    TiXmlDocument  Doc(strCfgFile.c_str());	
    if(!Doc.LoadFile())
    {
        throw CException(ERR_LOAD_XML_CFG, "Load xml config file error:" + strCfgFile, __FILE__, __LINE__);
    }


    /**
     * ��ȡMiddle������Ϣ
     */
    TiXmlNode* pMidNode = Doc.FirstChild("root")->FirstChild("middle")->FirstChild("connection");
    for(;pMidNode; pMidNode=NODE_NEXT(pMidNode))
    {
        string strServer = NODE_ATTR(pMidNode, "name");
        
        m_mapMidCfg[strServer].host = NODE_STR_VALUE(NODE_CHILD(pMidNode, "host"));
        m_mapMidCfg[strServer].user = NODE_STR_VALUE(NODE_CHILD(pMidNode, "user"));
        m_mapMidCfg[strServer].pswd = NODE_STR_VALUE(NODE_CHILD(pMidNode, "pswd"));
        m_mapMidCfg[strServer].port = NODE_INT_VALUE(NODE_CHILD(pMidNode, "port"));
        m_mapMidCfg[strServer].overtime = NODE_INT_VALUE(NODE_CHILD(pMidNode, "overtime"));
    }

    
    /**
     * ��ȡϵͳ������Ϣ
     */
    TiXmlNode* pSysNode = Doc.FirstChild("root")->FirstChild("system");
    m_SysCfg.log_path = NODE_STR_VALUE(NODE_CHILD(pSysNode, "log_path"));
    m_SysCfg.log_num = NODE_INT_VALUE(NODE_CHILD(pSysNode, "log_num"));
    m_SysCfg.log_size = NODE_INT_VALUE(NODE_CHILD(pSysNode, "log_size"));
	m_SysCfg.day_num = NODE_INT_VALUE(NODE_CHILD(pSysNode, "day_num"));
	m_SysCfg.modrefund_wd = NODE_STR_VALUE(NODE_CHILD(pSysNode, "modrefund_wd"));
    m_SysCfg.mid_no = NODE_INT_VALUE(NODE_CHILD(pSysNode, "mid_no"));

	
    /**
     * ��ȡDb������Ϣ
     */
    TiXmlNode* pDbConfNode = Doc.FirstChild("root")->FirstChild("db")->FirstChild("connection");
    for(;pDbConfNode; pDbConfNode=NODE_NEXT(pDbConfNode))
    {
        string strServer = NODE_ATTR(pDbConfNode, "name");
        
        m_mapDbCfg[strServer].host = NODE_STR_VALUE(NODE_CHILD(pDbConfNode, "host"));
        m_mapDbCfg[strServer].user = NODE_STR_VALUE(NODE_CHILD(pDbConfNode, "user"));
        m_mapDbCfg[strServer].pswd = NODE_STR_VALUE(NODE_CHILD(pDbConfNode, "pswd"));
        m_mapDbCfg[strServer].overtime = NODE_INT_VALUE(NODE_CHILD(pDbConfNode, "overtime"));
    }
}

