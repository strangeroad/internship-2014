#include "common.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <string>
#include "dbpool.h"
#include "md5.h"
extern CRpcWrapper* gPtrUserInfoServerRpc;

//#include "TAF_Common/TAF_Common.h"

using namespace std;
//using namespace TAF;

typedef long long LONG;

/**
 * ȫ�ֱ�������
 */
extern GlobalConfig* gPtrGlobalConfig;
extern CftLog* gPtrAppLog;
extern DbPool* gPtrDbPool;
extern string gStrSyncDate;
extern CRpcWrapper* gPtrItgDealRefundRpc; // itg_deal_refund_server����
extern CTransApi*  gPtrTrans; //�������������


using namespace std;

/**
 * ��ȡMD5ժҪ
 */
char* getMd5(const char *key, int len, char *szRes)
{
    struct MD5Context md5c;
    unsigned char digest[64];	

    MD5Init(&md5c);
    MD5Update(&md5c, (unsigned char *) key, len);
    MD5Final(digest, &md5c);

    for (int i = 0; i < 16; i++) 
    {
        sprintf(szRes + i * 2, "%02x", digest[i]);
    }

    szRes[32] = '\0';
    return szRes;
}

/**
 * ����ԭʼ��Ϣ
 * @input    pRequest        ��Ϣ������          
 * @output  szSpId            �̻�SPID
 *               szBuf              ���ܺ����Ϣ�ַ���
 */
void getDecodeMsg(TRPC_SVCINFO* pRequst, char* szBuf, char* szSpId) throw (CException)
{    
    // ���ؽ����Ϣ
    ST_PUB_ANS stAns;
    memset(&stAns, 0 ,sizeof(stAns));

    // ��ʱ����
    char szEncodeMsg[MAX_MSG_LEN] = {0};
    
    // ��ȡ��Ϣԭʼ���ܴ�
    CUrlAnalyze::getParam((char*)(pRequst->idata), "sp_id", szSpId, MAX_SP_LEN);
    CUrlAnalyze::getParam((char*)(pRequst->idata), "request_text", szEncodeMsg, MAX_MSG_LEN);

    // ������Ϣ����
    decode(szSpId, szEncodeMsg, szBuf, stAns);
    if(stAns.iResult != 0)
    {
        throw CException(stAns.iResult, stAns.szErrInfo, __FILE__, __LINE__);
    }
}

/**
 * ����ԭʼ��Ϣ
 * @input    szMsg        ��Ϣ������
             len          ��Ϣ������󳤶�
 *           szSpId       �̻�SPID
 * @output   ���ܺ����Ϣ�ַ�������
 */
void setEncodeMsg(char* szMsg, size_t len, const char* szSpId) throw (CException)
{
    char szBuf[MAX_MSG_LEN] = {0};
    ST_PUB_ANS stAns;
    
    // ���ܲ���
    encode(szSpId, szMsg, szBuf, stAns);
    if(stAns.iResult != 0)
    {
        throw CException(stAns.iResult, stAns.szErrInfo, __FILE__, __LINE__);
    }

    // ���������Ϣ
    snprintf(szMsg, len, "sp_id=%s&request_text=%s", szSpId, szBuf);
}

/**
 * �ж��Ƿ��������ַ���
 */
bool isDigitString(const char *str)
{
    const char* p = str;

    // �Թ�ǰ���ո�
    while(isspace(*p))  p++;

    // �Թ�����
    while(isdigit(*p))  p++;

    // �Թ�ĩβ�ո�
    while(isspace(*p))  p++;
    
    return !(*p);
}

/**
 * ������ת��Ϊ�ַ���
 */
string toString(int value)
{
    char szTmp[128];
    sprintf(szTmp, "%d", value);
    return szTmp;
}

/**
 * ������ת��Ϊ�ַ���
 */
string toString(LONG value)
{
    char szTmp[128];
    sprintf(szTmp, "%lli", value);
    return szTmp;
}

/**
 * ���ַ���ת��Ϊ����
 */
int toInt(const char* value)
{
    return value ? atoi(value) : 0;
}

/**
 * ���ַ���ת��Ϊ������
 */
LONG toLong(const char* value)
{
    return value ? atoll(value) : 0;
}

/**
 * ���ַ���ת��ΪСд
 */
string& toLower(string& str)
{
    for(string::iterator it=str.begin(); it != str.end(); ++it)
    {
        *it = tolower(*it);
    }

    return str;
}

/**
 * ���ַ���ת��ΪСд
 */
char* toLower(char* sz)
{
    for(char* p=sz; *p; p++)
    {
        *p = tolower(*p);
    }
    return sz;
}

/**
 * ���ַ���ת��Ϊ��д
 */
string& toUpper(string& str)
{
    for(string::iterator it=str.begin(); it != str.end(); ++it)
    {
        *it = toupper(*it);
    }

    return str;
}

/**
 * ���ַ���ת��Ϊ��д
 */
char* toUpper(char* sz)
{
    for(char* p=sz; *p; p++)
    {
        *p = toupper(*p);
    }
    return sz;
}

/**
 * ��ʱ��ת��Ϊϵͳʱ��
 * @input       strTime     YYYY-MM-DD HH:MM:SS
 */
time_t toUnixTime(const string& strTime)
{
    // ȡ�ꡢ�¡��ն�
    int year, month, day, hour, minute, second;
    sscanf(strTime.c_str(), "%04d-%02d-%02d %02d:%02d:%02d", &year, &month, &day, &hour, &minute, &second);

    // ������С��1900������0
    if(year < 1900)     return 0;

    // ת��Ϊ����ʱ��
    struct  tm tm_date;
    memset(&tm_date, 0, sizeof(tm));

    tm_date.tm_year =  year - 1900;
    tm_date.tm_mon = month - 1;
    tm_date.tm_mday = day;
    tm_date.tm_hour = hour;
    tm_date.tm_min = minute;
    tm_date.tm_sec = second;

    // ת��Ϊϵͳʱ��
    return  mktime(&tm_date);
}

/**
 * ��ȡϵͳʱ��: YYYY-MM-DD HH:MM:SS
 */
string getSysTime()
{
    return getSysTime(time(NULL));
}

/**
 * ��ȡϵͳʱ��: YYYY-MM-DD HH:MM:SS
 */
string getSysTime(time_t t)
{
    struct  tm tm_now;
    localtime_r(&t, &tm_now);
    
    char szTmp[256];
    sprintf(szTmp, "%04d-%02d-%02d %02d:%02d:%02d",
                tm_now.tm_year + 1900, tm_now.tm_mon + 1, tm_now.tm_mday,
                tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);

    return szTmp;
}

/**
 * ȡĳ������N��ǰ������
 * @input:      strDate     YYYYMMDD
 *                  N   ֮ǰN��
 * @return:    YYYYMMDD
 */
string subDate(const string& strDate, int N)
{
    // ȡ�ꡢ�¡��ն�
    int year, month, day, hour, min, sec;
    sscanf(strDate.c_str(), "%04d-%02d-%02d %02d:%02d:%02d", &year, &month, &day, &hour, &min, &sec);


    // ת��Ϊ����ʱ��
    struct  tm tm_date;
    memset(&tm_date, 0, sizeof(tm));

    tm_date.tm_year =  year - 1900;
    tm_date.tm_mon = month - 1;
    tm_date.tm_mday = day;
    tm_date.tm_hour = hour;
    tm_date.tm_min = min;
    tm_date.tm_sec = sec;

    // ת��Ϊϵͳʱ��
    time_t tSysTime = mktime(&tm_date);

    // ����ǰN���ϵͳʱ��
    tSysTime -= N * 86400;

    // ת��Ϊ����ʱ��
    localtime_r(&tSysTime, &tm_date);

    char szTmp[256];
    sprintf(szTmp, "%04d-%02d-%02d %02d:%02d:%02d", tm_date.tm_year + 1900, tm_date.tm_mon + 1, tm_date.tm_mday,
                                                    tm_date.tm_hour, tm_date.tm_min, tm_date.tm_sec);    

    return szTmp;
}    


/**
 * ȡʱ����겿��
 *@input:   str   YYYY-MM-DD HH:MM:SS
 */
int year(const string& str)
{
    int year, month, day;
    sscanf(str.c_str(), "%04d-%02d-%02d", &year, &month, &day);
    return year;
}

/**
 * ȡʱ����²���
 *@input:   str   YYYY-MM-DD HH:MM:SS
 */
int month(const string& str)
{
    int year, month, day;
    sscanf(str.c_str(), "%04d-%02d-%02d", &year, &month, &day);
    return month;
}

/**
 * ȡʱ����ղ���
 *@input:   str   YYYY-MM-DD HH:MM:SS
 */
int day(const string& str)
{
    int year, month, day;
    sscanf(str.c_str(), "%04d-%02d-%02d", &year, &month, &day);
    return day;
}

/**
 * ���ַ����е�a�ַ��滻Ϊb�ַ�
 */
char* replace(char* str, char a, char b)
{
    std::replace(str, str + strlen(str), a, b);

    return str;
}

string escapeString(char *szStr, int len)
{
	char szTmp[1024];
	memset(szTmp, 0, sizeof(szTmp));
	mysql_escape_string(szTmp, szStr, len);
    szTmp[ strlen(szTmp)-1 ] = '\0';
	return szTmp;
}

std::string do_escape(const std::string&what)
{
    string target;
    target.resize(0);
    string _s = "%%";
    string _r = "\\%";

    if (what.size()==0)
        return target;

    char * escaped = new char[what.size()*2+1];
    if (!escaped) {
        return target;
    }
    memset(escaped,'\0',what.size()*2+1);
    mysql_escape_string(escaped,what.c_str(),what.size());
    target = escaped;

//    string::size_type it = target.find(_s);

#if 0
    while (it!=string::npos) {
        target.replace(it,1,_r);
        //cout << "target: " << target.c_str()<< endl;
        ++it;++it;++it;
        it = target.find(_s,it);
    }
#endif
    if (escaped)
        delete[]escaped;
    return target;
}

/**
 * ����ȫ����Ϣ��
 * @input: buf ��Ϣ�ŵĴ������
 */
string makeMsgNo()
{
    char buf[64] = {0};

    static unsigned int seq = 0;
    static int proc = getpid();
    
    snprintf(buf, 64, "%03d%05d%010u%010u", 143, proc, (int)time(NULL), seq++);

    return buf;
}


/**
 * ��ȡ��ǰ����IP
 */
string getLocalHostIp()
{   
    int fd, intrface;
    long ip = -1;
    char szBuf[128] = {0};
    struct ifreq buf[16];
    struct ifconf ifc; 
    
    if((fd=socket (AF_INET, SOCK_DGRAM, 0)) >= 0) 
    {
        ifc.ifc_len = sizeof buf;
        ifc.ifc_buf = (caddr_t) buf;
        if (!ioctl(fd, SIOCGIFCONF, (char*)&ifc)) 
        {
            intrface = ifc.ifc_len / sizeof(struct ifreq);
            while(intrface-- > 0)
            {
                if (!(ioctl (fd, SIOCGIFADDR, (char *) &buf[intrface])))
                {
                    ip=inet_addr(inet_ntoa(((struct sockaddr_in*)(&buf[intrface].ifr_addr))->sin_addr));   

                    if (ip != 0 && ip != 0x0100007f)
                    {
                        // ����ȡ��0.0.0.0����127.0.0.1
                        break;
                    }
                }
            }
        }
        close (fd);
    }

    // ת��Ϊ.��ʽ
    unsigned char* pIp = (unsigned char*)(&ip);
    sprintf(szBuf, "%u.%u.%u.%u", pIp[0], pIp[1], pIp[2], pIp[3]);
    
    return szBuf;
}


