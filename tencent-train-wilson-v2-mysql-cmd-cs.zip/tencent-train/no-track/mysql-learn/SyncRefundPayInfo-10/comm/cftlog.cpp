#include <stdarg.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <time.h>
#include <errno.h>
#include "cftlog.h"

/**
 * ÿ�μ�¼����־����
 */
#define WRITE_LOG(buf, str)\
    int iBufLen = 0;\
    time_t tnow;\
    struct tm tm;\
    tnow = time(NULL);\
    localtime_r(&tnow, &tm);\
    iBufLen = snprintf(buf, sizeof(buf), \
    "[%04d-%02d-%02d %02d:%02d:%02d][%d][%s]",\
            tm.tm_year + 1900, tm.tm_mon + 1,\
            tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,\
            _proc_id, str);\
\
    va_list ap;\
    va_start(ap, fmt);\
    iBufLen += vsnprintf(buf + iBufLen, sizeof(buf) - iBufLen, fmt, ap);\
    va_end(ap);\
    buf[iBufLen++] = '\n';\
    buf[iBufLen] = '\0';\
    return _write(buf, iBufLen);

/**
 * ���캯��
 */
CftLog::CftLog(const char *path, int max_size, int max_num)
{
    // ��Ա��ʼ��
    _path = path;
    _max_size = max_size;
    _max_file = max_num;
    _level = _DEBUG;
    _proc_id = getpid();
    _fd = -1;
}


/**
 * ��������
 */
CftLog::~CftLog()
{
    // �ر��ļ�
    close(_fd);
}

/**
 * ���ļ�
 */
int CftLog::_open()
{
    if (_fd == -1) 
    {
        string strFile = _path + ".log";
        if ((_fd = open(strFile.c_str(), O_CREAT | O_WRONLY | O_APPEND, 0644)) < 0) 
        {
            snprintf(_szErrInfo, sizeof(_szErrInfo), "open %s error:%s", strFile.c_str(), strerror(errno));
            fprintf(stderr, "%s", _szErrInfo);
            _fd = -1;
            return -1;
        }
    }

    return 0;
}

/**
 * �ر��ļ�
 */
void CftLog::_close()
{
    if (_fd != -1) 
    {
        close(_fd);
        _fd = -1;
    }
}

/**
 * ��ӡ����log
 */
int CftLog::error(const char *fmt, ...)
{
    char buf[MAX_BUF];
    
    if (_level < _ERROR) 
    {
        return 0;
    }

    WRITE_LOG(buf, "ERROR");
}

/**
 * ��ӡ�澯log
 */
int CftLog::warning(const char *fmt, ...)
{
    char buf[MAX_BUF];
    
    if (_level < _WARNING) 
    {
        return 0;
    }

    WRITE_LOG(buf, "WARNING");
}

/**
 * ��ӡ����log
 */
int CftLog::normal(const char *fmt, ...)
{
    char _buf[MAX_BUF];
    
    if (_level < _NORMAL) 
    {
        return 0;
    }
    
    WRITE_LOG(_buf, "NORMAL");
}

/**
 * ��ӡ����log
 */
int CftLog::debug(const char *fmt, ...)
{
    char buf[MAX_BUF];
    
    if (_level < _DEBUG) 
    {
        return 0;
    }
    WRITE_LOG(buf, "DEBUG");
}

/**
 * ��¼��־
 */
int CftLog::_write(const char *str, int len)
{  
    // ��־����������
    static int __count = 0;

    if (_fd == -1) 
    {
        if (_open() != 0) 
        {
            snprintf(_szErrInfo, sizeof(_szErrInfo), "open %s.log error:%s", _path.c_str(), strerror(errno));
            return -1;
        }
    }

    int ret = write(_fd, str, len);
    if (ret < 0) 
    {
        _close();
        snprintf(_szErrInfo, sizeof(_szErrInfo), "puts %s.log error:%s", _path.c_str(), strerror(errno));
        return ret;
    }
    
    // �Ƿ�Ҫִ����־�л�
    if((__count++) >= SHIFT_FREQ)
    {
       _shift();
       __count = 0;
    }
        
    return 0;
}

/**
 * �л���־�ļ�
 */
int CftLog::_shift()
{
    struct stat stStat;
    char szOrigFile[1024];
    char szNewFile[1024];
    
    // �ر��ļ�(ǿ�ƽ����л�)
    _close();  
    _open();
    
    // ���Ե�ǰ��־�ļ���С
    if(fstat(_fd, &stStat) < 0) 
    {
        snprintf(_szErrInfo, sizeof(_szErrInfo), "stat file %s.log error:%s", _path.c_str(), strerror(errno));
        return -1;
    }

    // ����ǰ�ļ���СС�����ֵ
    if (stStat.st_size < _max_size) 
    {
        return 0;
    }

    // ɾ�����һ����־�ļ�
    sprintf(szNewFile, "%s%d.log", _path.c_str(), _max_file - 1);
    if (access(szNewFile, F_OK) == 0) 
    {
        if (remove(szNewFile) < 0) 
        {
            snprintf(_szErrInfo, sizeof(_szErrInfo), "remove file %s error:%s", szNewFile, strerror(errno));
            return -1;
        }
    }

    // �ۼ��ļ����(�л��ļ���)
    for(int i = _max_file - 2; i >= 0; i--) 
    {
        if (i == 0) 
        {
            sprintf(szOrigFile, "%s.log", _path.c_str());
            sprintf(szNewFile, "%s%d.log", _path.c_str(), i+1);
        }
        else 
        {
            sprintf(szOrigFile, "%s%d.log", _path.c_str(), i);
            sprintf(szNewFile, "%s%d.log", _path.c_str(), i+1);
        }

        if(access(szOrigFile, F_OK) == 0) 
        {
            if (rename(szOrigFile, szNewFile) < 0) 
            {
                snprintf(_szErrInfo, sizeof(_szErrInfo), "rename file %s to %s error:%s", szOrigFile, szNewFile, strerror(errno));
                return -1;
            }
        }
    }

    // �ر��ļ�
    _close();  
    
    return 0;
}

