#ifndef _APP_COMMON_H_
#define _APP_COMMON_H_

#include "error.h"
#include "cftlog.h"
#include "globalconfig.h"
#include "sqlapi.h"
#include "exception.h"
#include "common.h"
#include "TransApi.h"
#include "TransCmd.h"
#include "trpcwrapper.h"
#include "UrlAnalyze.h"

#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

using std::vector;
using std::set;

using std::map;
using CFT::CUrlAnalyze;

typedef long long LONG;
typedef  map<string,string> CStr2Map;

class CSyncRefundPayInfo
{
public:

    CSyncRefundPayInfo();
    ~CSyncRefundPayInfo();

    void syncRefundPayInfo() throw (CException);    

private:

  /* װ�ظ����˿���Ϣ */
  void loadRefundPayInfo()throw (CException);
  void queryRefundInfo(const string& sSpid, const string& sDrawId, CStr2Map &szmRefundInfo) throw(CException);
  void modifyRefundChargeInfo(CStr2Map &szmInput) throw(CException);
};

#endif

