#ifndef _DBPOOL_H_
#define _DBPOOL_H_

#include "exception.h"
#include "common.h"
#include "sqlapi.h"
#include <algorithm>
#include <map>
#include <string>
#include <vector>
#include <iostream>

using std::map;
using std::string;
using std::vector;
using std::ostream;

const int MIN_SPEC_SUFFIX = 0;
const int MAX_SPEC_SUFFIX = 99;

/**
 * �ֶ�����
 */
struct SpecConn
{
    int         index;          // �ֶα��
    CMySQL*     ptrSqlConn;     // �ֶ����ݿ�����
};

/**
 * �ֶ�
 */
struct Spec
{
public:
    
    /**
     * ����׼��
     */
    struct SortCriterion
    {
    public:
        bool operator()(const Spec left, const Spec right) const;
    };
    
public:
    
    int         start;     // �ֶ���ʼ
    int         end;       // �ֶ���ֹ
    string      host;      // IP��ַ
    string      user;      // �û���
    string      pswd;      // ����
    int         overtime;  // ��ʱʱ��
    SpecConn    specConn;  // �ֶ����ݿ�����
};

class DbPool
{
public:
    
    /**
     * ���캯��
     */
    DbPool();

    /**
     * ��������
     */
    ~DbPool();

    /**
     * ��ʼ��
     */
    void init() throw(CException);

    /**
     * ���ӷֶ�
     */
    void addSpec(
        const string& range, 
        const string& host,
        const string& user, 
        const string& pswd, 
        const int overtime) throw(CException);

    /**
     * ȡ�ֶ�����
     */
    SpecConn* getConnection(const string& listid, bool checkAlive = false) throw(CException);

    /**
     * ȡ�ֶ�����
     */
    SpecConn* getConnection(int specIndex, bool checkAlive = false) throw(CException);


    /**
     * ���ֶ������Ƿ���Ч
     */
    void checkSpecAlive(int specIndex) throw(CException);

protected:

    /**
     * ���ֶ�
     */
    void checkSpec() throw(CException);

    
protected:

    /**
     * DBPOOL �Ƿ��Ѿ���ʼ��
     */
    bool m_bInit;

    /**
     * Spec�б�
     */
    vector<Spec> m_vecSpec;

};

inline CMySQL* SPEC_SQL(DbPool* ptrDbPoll, int iSpecIndex) throw(CException)
{
    return ptrDbPoll->getConnection(iSpecIndex)->ptrSqlConn;
}

inline CMySQL* SPEC_SQL(DbPool* ptrDbPoll, const string& listid) throw(CException)
{
    return ptrDbPoll->getConnection(listid)->ptrSqlConn;
}

inline int SPEC_INDEX(DbPool* ptrDbPoll, const string& listid) throw(CException)
{
    return ptrDbPoll->getConnection(listid)->index;
}

#endif // _DBPOOL_H_

