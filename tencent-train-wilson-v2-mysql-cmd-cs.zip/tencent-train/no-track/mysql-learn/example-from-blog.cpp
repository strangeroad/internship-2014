/*
 * =====================================================================================
 *
 *       Filename:  example-from-blog.cpp
 *
 *    Description:  http://blog.csdn.net/whuqin/article/details/7757841
 *
 *        Version:  1.0
 *        Created:  2014年07月30日 16时45分11秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include <iostream>
#include <mysql++.h>  
using namespace std;
int main(int argc, char* argv[]){
    const char *db="public0", *server="localhost", *user="public", *pass="public";
    // Connect to the sample database.  
    mysqlpp::Connection conn(false);  
    if (conn.connect(db, server, user, pass)) {  
        const char *sql_create="create table if not exist account (name varchar(32) not NULL, money int default 0, primary_key(name));";
        mysqlpp::Query query = conn.query(sql_create);
        // Retrieve a subset of the sample stock table set up by resetdb  
        // and display it.  
        mysqlpp::Query query = conn.query("select name from count;");  
        if (mysqlpp::StoreQueryResult res = query.store()) {  
           cout << "We have:" << endl;  
           for (size_t i = 0; i < res.num_rows(); ++i) {  
                cout << '\t' << res[i][0] << endl;  
             }  
         }  
         else {  
            cerr << "Failed to get item list: " << query.error() << endl;  
            return 1;  
         }  
         return 0;  
    }  
    else {  
        cerr << "DB connection failed: " << conn.error() << endl;  
        return 1;  
    }  
    return 0;
}
