/*
 * =====================================================================================
 *
 *       Filename:  test-mysql++.cpp
 *
 *    Description:  official example
 *
 *        Version:  1.0
 *        Created:  2014年07月30日 15时48分25秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <iostream>
#include <mysql++.h>

int main() {

mysqlpp::String s("Hello World 2014-07-30");

std::cout << s << std::endl;

return 0;

}

// g++ -o test test-mysql++.cpp -I/usr/include/mysql -I/usr/include/mysql++  -L/usr/lib -lmysqlpp -lmysqlclient

