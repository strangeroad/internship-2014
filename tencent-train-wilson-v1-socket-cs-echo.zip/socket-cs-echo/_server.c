/*
 * =====================================================================================
 *
 *       Filename:  _server.c
 *
 *    Description:  服务端 仅echo功能
 *
 *        Version:  1.0
 *        Created:  2014年07月29日 09时47分29秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  wilsonwuwu (吴伟顺), 582223837@qq.com
 *   Organization:  
 *
 * =====================================================================================
 */
#include <stdlib.h>

#include <stdio.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string.h>

#define MAXLINE 4096

int err_handle(const char* str);

int main(int argc, char* argv[]){
    /* socket bind listen accept close */

    int port = 8000;
    if (argc >=2 )
        sscanf(argv[1], "%d", &port);

    int socket_server = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_server == -1)
        err_handle("create");
    
    struct sockaddr_in  serv_addr, client_addr;
    memset(&serv_addr, 0, sizeof(struct sockaddr_in));
    memset(&client_addr, 0, sizeof(struct sockaddr_in));
    /* 字节序： 人左到有，CPU低位到高位，四字决“大同小异”，网络序是小端 */
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port);
    if (bind(socket_server, (struct sockaddr*)&serv_addr, sizeof(serv_addr))< 0)
        err_handle("bind");
    /* 出现bind error情况：服务断强制结束后一小段时间内重开  bind error: Address already in use [98] */

    if (listen(socket_server, 10000) == -1)
        err_handle("listen");

    printf("listen at port %d ...\n", port);

    while (1){

        socklen_t addrlen = 0;
        /* 
        int socket_client = accept(socket_server,
                (struct sockaddr*)&client_addr,
                &addrlen);
         */
        int socket_client = accept(socket_server,
                (struct sockaddr*)NULL,
                NULL);
        printf("new session [socket:%d]\n", socket_client); 

        char buf_recv[MAXLINE]="\0", buf_send[MAXLINE]="\0";
        while (1){
            int len = recv(socket_client, buf_recv, MAXLINE, 0);
            if (len < 0)    err_handle("recv");
            /* CTRL+D时，len>0 */
            if (len == 0 || buf_recv[0]=='\0')   break;

            /* 不用buf_recv[len] = '\0' 测试显示 自动就有了 */
            buf_recv[MAXLINE] = '\0'; /* safe */
            printf("recv: %s [strlen:%d]\n", buf_recv, strlen(buf_recv));
            if (0 == strcmp(buf_recv, "exit"))
                break;

            strncpy(buf_send, buf_recv, MAXLINE);

            buf_send[MAXLINE] = '\0'; /* safe */
            if (send(socket_client, buf_send, MAXLINE, 0) < 0)
                err_handle("send");
        }

        close(socket_client);
    }

    return 0;
}

int err_handle(const char* str){
    printf("%s error: %s [%d]\n", str, strerror(errno), errno);
    exit(-1);
}
